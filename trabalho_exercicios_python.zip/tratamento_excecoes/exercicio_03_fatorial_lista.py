# Exercício 3 - Calcular fatorial de cada número de uma lista com tratamento de exceções

import math

lista = [5, 3, 'a', -2, 4]

for elemento in lista:
    try:
        if not isinstance(elemento, int):
            raise TypeError('O elemento não é um número inteiro.')

        if elemento < 0:
            raise ValueError('Não existe fatorial de número negativo.')

        resultado = math.factorial(elemento)
        print(f'Fatorial de {elemento}: {resultado}')

    except TypeError as erro:
        print(f'Erro no elemento {elemento}: {erro}')

    except ValueError as erro:
        print(f'Erro no elemento {elemento}: {erro}')
