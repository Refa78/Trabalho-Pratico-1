# Exercício 5 - Ler nome completo, converter iniciais para maiúsculas e armazenar em arquivo

try:
    nome_completo = input('Digite o nome completo: ').strip()

    if len(nome_completo) == 0:
        raise ValueError('O nome não pode estar vazio.')

    if not nome_completo.replace(' ', '').isalpha():
        raise ValueError('O nome deve conter apenas letras e espaços.')

    nome_formatado = nome_completo.title()

    try:
        with open('saida/nomes_formatados.txt', 'a', encoding='utf-8') as arquivo:
            arquivo.write(nome_formatado + '\n')

        print(f'Nome salvo com sucesso: {nome_formatado}')

    except FileNotFoundError:
        print('Erro: o diretório ou arquivo não foi encontrado.')

except ValueError as erro:
    print(f'Erro: {erro}')
