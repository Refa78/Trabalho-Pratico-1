# Exercício 2 - Ler dois números inteiros e realizar divisão com tratamento de exceções

try:
    numero1 = int(input('Digite o primeiro número inteiro: '))
    numero2 = int(input('Digite o segundo número inteiro: '))

    resultado = numero1 / numero2
    print(f'Resultado da divisão: {resultado}')

except ZeroDivisionError:
    print('Erro: não é possível dividir por zero.')

except ValueError:
    print('Erro: um dos valores digitados não é número inteiro.')
