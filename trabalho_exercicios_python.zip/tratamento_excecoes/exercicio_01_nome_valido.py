# Exercício 1 - Ler um nome e verificar se é uma string válida usando try/except

try:
    nome = input('Digite um nome: ').strip()

    if not nome.replace(' ', '').isalpha():
        raise ValueError('O nome deve conter apenas letras e espaços.')

    if len(nome) == 0:
        raise ValueError('O nome não pode estar vazio.')

    print(f'Nome válido: {nome}')

except ValueError as erro:
    print(f'Erro: {erro}')
