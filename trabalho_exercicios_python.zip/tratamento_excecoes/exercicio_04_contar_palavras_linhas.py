# Exercício 4 - Contar palavras e linhas de um arquivo, verificando se ele existe no diretório

try:
    with open('entrada/texto.txt', 'r', encoding='utf-8') as arquivo:
        linhas = arquivo.readlines()

    quantidade_linhas = len(linhas)
    quantidade_palavras = 0

    for linha in linhas:
        quantidade_palavras += len(linha.split())

    print(f'Quantidade de linhas: {quantidade_linhas}')
    print(f'Quantidade de palavras: {quantidade_palavras}')

except FileNotFoundError:
    print('Erro: o arquivo não foi encontrado no diretório informado.')
