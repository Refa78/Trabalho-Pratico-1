# Exercício 2 - Ler dados de uma pessoa, calcular idade e armazenar em arquivo txt

import os
from datetime import datetime

os.makedirs('saida', exist_ok=True)

nome = input('Digite o nome: ')
rg = input('Digite o RG: ')
cpf = input('Digite o CPF: ')
ano_nascimento = int(input('Digite o ano de nascimento: '))

ano_atual = datetime.now().year
idade = ano_atual - ano_nascimento

with open('saida/dados_pessoa.txt', 'w', encoding='utf-8') as arquivo:
    arquivo.write('DADOS DA PESSOA\n')
    arquivo.write(f'Nome: {nome}\n')
    arquivo.write(f'RG: {rg}\n')
    arquivo.write(f'CPF: {cpf}\n')
    arquivo.write(f'Ano de nascimento: {ano_nascimento}\n')
    arquivo.write(f'Idade: {idade} anos\n')

print('Dados salvos em saida/dados_pessoa.txt')
