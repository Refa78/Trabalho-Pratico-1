# Exercício 1 - Inserir a tabuada de multiplicação de 9 em um arquivo txt

import os

os.makedirs('saida', exist_ok=True)

with open('saida/tabuada_9.txt', 'w', encoding='utf-8') as arquivo:
    arquivo.write('Tabuada de multiplicação do 9\n')
    arquivo.write('-' * 30 + '\n')

    for numero in range(1, 11):
        resultado = 9 * numero
        arquivo.write(f'9 x {numero} = {resultado}\n')

print('Arquivo saida/tabuada_9.txt criado com sucesso!')
