# Exercício 5 - Mini calculadora com dois números inteiros e armazenamento dos resultados em txt

import os

os.makedirs('saida', exist_ok=True)

numero1 = int(input('Digite o primeiro número inteiro: '))
numero2 = int(input('Digite o segundo número inteiro: '))

soma = numero1 + numero2
subtracao = numero1 - numero2
multiplicacao = numero1 * numero2

divisao = 'Não é possível dividir por zero' if numero2 == 0 else numero1 / numero2

with open('saida/calculadora.txt', 'w', encoding='utf-8') as arquivo:
    arquivo.write('MINI CALCULADORA\n')
    arquivo.write(f'Número 1: {numero1}\n')
    arquivo.write(f'Número 2: {numero2}\n')
    arquivo.write(f'Soma: {soma}\n')
    arquivo.write(f'Subtração: {subtracao}\n')
    arquivo.write(f'Multiplicação: {multiplicacao}\n')
    arquivo.write(f'Divisão: {divisao}\n')

print('Resultados salvos em saida/calculadora.txt')
