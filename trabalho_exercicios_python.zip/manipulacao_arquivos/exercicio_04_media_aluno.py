# Exercício 4 - Ler nome e duas notas, calcular média e armazenar aprovação em arquivo txt

import os

os.makedirs('saida', exist_ok=True)

nome = input('Digite o nome do aluno: ')
nota1 = float(input('Digite a primeira nota: '))
nota2 = float(input('Digite a segunda nota: '))

media = (nota1 + nota2) / 2
situacao = 'Aprovado' if media >= 6 else 'Reprovado'

with open('saida/media_aluno.txt', 'w', encoding='utf-8') as arquivo:
    arquivo.write('RESULTADO DO ALUNO\n')
    arquivo.write(f'Nome: {nome}\n')
    arquivo.write(f'Média final: {media:.2f}\n')
    arquivo.write(f'Situação: {situacao}\n')

print('Resultado salvo em saida/media_aluno.txt')
