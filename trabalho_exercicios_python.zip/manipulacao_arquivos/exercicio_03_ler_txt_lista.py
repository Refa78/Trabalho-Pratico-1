# Exercício 3 - Ler um arquivo txt e inserir cada linha em uma lista

linhas = []

with open('entrada/texto.txt', 'r', encoding='utf-8') as arquivo:
    for linha in arquivo:
        linhas.append(linha.strip())

print('Lista criada com as linhas do arquivo:')
print(linhas)
