# Exercício 1 - Ler uma cadeia de DNA de um arquivo txt e gerar a cadeia inversa

with open('entrada/dna.txt', 'r', encoding='utf-8') as arquivo:
    cadeia_dna = arquivo.read().strip()

cadeia_inversa = cadeia_dna[::-1]

print(f'Entrada: {cadeia_dna}')
print(f'Saída: {cadeia_inversa}')
