# Exercício 2 - Ler texto de arquivo txt e contar quantas palavras existem no arquivo

with open('entrada/texto.txt', 'r', encoding='utf-8') as arquivo:
    texto = arquivo.read()

palavras = texto.split()
quantidade_palavras = len(palavras)

print(f'Quantidade de palavras no arquivo: {quantidade_palavras}')
