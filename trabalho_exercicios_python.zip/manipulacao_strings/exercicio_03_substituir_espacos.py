# Exercício 3 - Ler texto de arquivo txt e substituir espaços por underline

import os

os.makedirs('saida', exist_ok=True)

with open('entrada/texto.txt', 'r', encoding='utf-8') as arquivo:
    texto = arquivo.read()

texto_modificado = texto.replace(' ', '_')

with open('saida/texto_com_underline.txt', 'w', encoding='utf-8') as arquivo:
    arquivo.write(texto_modificado)

print('Texto modificado salvo em saida/texto_com_underline.txt')
print(texto_modificado)
