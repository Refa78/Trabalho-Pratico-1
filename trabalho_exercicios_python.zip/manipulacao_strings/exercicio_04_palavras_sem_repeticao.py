# Exercício 4 - Ler frases de arquivo txt e inserir cada palavra em uma lista, sem repetição

palavras_sem_repeticao = []

with open('entrada/frases.txt', 'r', encoding='utf-8') as arquivo:
    texto = arquivo.read()

palavras = texto.split()

for palavra in palavras:
    if palavra not in palavras_sem_repeticao:
        palavras_sem_repeticao.append(palavra)

print('Lista de palavras sem repetição:')
print(palavras_sem_repeticao)
