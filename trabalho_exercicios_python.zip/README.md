# Trabalho - Exercícios de Python

Disciplina: Desenvolvimento Rápido de Aplicações em Python  
Professora: Simone Gama

## Organização

Este repositório contém os exercícios solicitados, separados por tema:

- `manipulacao_arquivos/`
- `manipulacao_strings/`
- `tratamento_excecoes/`
- `entrada/` - arquivos `.txt` usados como entrada nos exercícios
- `saida/` - arquivos `.txt` gerados pelos programas
- `componentes_grupo.txt` - dados dos componentes do grupo

## Como executar

Abra a pasta no VS Code apenas para executar os scripts.

No terminal, rode os arquivos com:

```bash
python nome_do_arquivo.py
```

Exemplo:

```bash
python manipulacao_arquivos/exercicio_01_tabuada_9.py
```

Os arquivos de saída serão criados ou atualizados dentro da pasta `saida/`.
