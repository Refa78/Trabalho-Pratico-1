"""
Exercício de Manipulação de Arquivos 1
Elabore um programa em Python que insere a tabuada de multiplicação de 9 em um arquivo txt.
"""

arquivo_saida = "../saidas/tabuada_9.txt"

with open(arquivo_saida, "w", encoding="utf-8") as arquivo:
    arquivo.write("Tabuada de multiplicação do 9\n")
    arquivo.write("-" * 30 + "\n")

    for numero in range(1, 11):
        resultado = 9 * numero
        arquivo.write(f"9 x {numero} = {resultado}\n")

print(f"Arquivo '{arquivo_saida}' criado com sucesso.")
