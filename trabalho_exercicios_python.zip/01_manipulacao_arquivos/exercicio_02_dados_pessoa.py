"""
Exercício de Manipulação de Arquivos 2
Faça um programa que leia os dados de uma pessoa (Nome, RG, CPF, ano de nascimento)
e armazene em um arquivo txt, calculando a idade da pessoa.
"""

from datetime import datetime

arquivo_saida = "../saidas/dados_pessoa.txt"
ano_atual = datetime.now().year

nome = input("Digite o nome: ")
rg = input("Digite o RG: ")
cpy = input("Digite o CPF: ")
ano_nascimento = int(input("Digite o ano de nascimento: "))

idade = ano_atual - ano_nascimento

with open(arquivo_saida, "w", encoding="utf-8") as arquivo:
    arquivo.write("Dados da Pessoa\n")
    arquivo.write("-" * 30 + "\n")
    arquivo.write(f"Nome: {nome}\n")
    arquivo.write(f"RG: {rg}\n")
    arquivo.write(f"CPF: {cpf}\n")
    arquivo.write(f"Ano de nascimento: {ano_nascimento}\n")
    arquivo.write(f"Idade: {idade} anos\n")

print(f"Dados gravados no arquivo '{arquivo_saida}'.")
